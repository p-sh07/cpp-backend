//
// Created by Pavel on 19.12.2024.
//

#include "database.h"

namespace database {


}