//
// Created by Pavel on 19.12.2024.
//
#pragma once;
#include <pqxx/zview>
#include <pqxx/pqxx>
#include <condition_variable>
#include <vector>
#include <string>
#include <optional>

#include "game_data.h"

namespace database {
class ConnectionPool {
    using PoolType = ConnectionPool;
    using ConnectionPtr = std::shared_ptr<pqxx::connection>;

public:
    class ConnectionWrapper {
    public:
        ConnectionWrapper(std::shared_ptr<pqxx::connection>&& conn, PoolType& pool) noexcept
            : conn_{std::move(conn)}
        , pool_{&pool} {
        }

        ConnectionWrapper(const ConnectionWrapper&) = delete;
        ConnectionWrapper& operator=(const ConnectionWrapper&) = delete;

        ConnectionWrapper(ConnectionWrapper&&) = default;
        ConnectionWrapper& operator=(ConnectionWrapper&&) = default;

        pqxx::connection& operator*() const& noexcept {
            return *conn_;
        }
        pqxx::connection& operator*() const&& = delete;

        pqxx::connection* operator->() const& noexcept {
            return conn_.get();
        }

        ~ConnectionWrapper() {
            if (conn_) {
                pool_->ReturnConnection(std::move(conn_));
            }
        }

    private:
        std::shared_ptr<pqxx::connection> conn_;
        PoolType* pool_;
    };

    // ConnectionFactory is a functional object returning std::shared_ptr<pqxx::connection>
    template <typename ConnectionFactory>
    ConnectionPool(size_t capacity, ConnectionFactory&& connection_factory) {
        pool_.reserve(capacity);
        for (size_t i = 0; i < capacity; ++i) {
            pool_.emplace_back(connection_factory());
        }
    }

    ConnectionWrapper GetConnection() {
        std::unique_lock lock{mutex_};
        // Блокируем текущий поток и ждём, пока cond_var_ не получит уведомление и не освободится
        // хотя бы одно соединение
        // Добавлен таймаут в 1 сек
        // После выхода из цикла ожидания мьютекс остаётся захваченным
        if (cond_var_.wait_for(lock, std::chrono::milliseconds(1000u), [this] {
            return used_connections_ < pool_.size();
        })) {
            return {std::move(pool_[used_connections_++]), *this};
        }
        throw std::runtime_error("unable to aquire connection to db");
    }

private:
    void ReturnConnection(ConnectionPtr&& conn) {
        // Возвращаем соединение обратно в пул
        {
            std::lock_guard lock{mutex_};
            assert(used_connections_ != 0);
            pool_[--used_connections_] = std::move(conn);
        }
        // Уведомляем один из ожидающих потоков об изменении состояния пула
        cond_var_.notify_one();
    }

    std::mutex mutex_;
    std::condition_variable cond_var_;
    std::vector<ConnectionPtr> pool_;
    size_t used_connections_ = 0;
};

class PlayerStats {
protected:
    ~PlayerStats() = default;

public:
    virtual std::vector<gamedata::PlayerStats> LoadPlayersStats(std::optional<size_t> start, std::optional<size_t> maxItems) = 0;
    virtual void SavePlayersStats(const std::vector<gamedata::PlayerStats>& players_stats) = 0;
};

} //namespace database